<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\RouteEnrollmentEventRequest;
use App\Jobs\ProcessEnrollmentEvent;
use App\Services\EnrollmentEvents\EnrollmentEventFilter;
use App\Services\EnrollmentEvents\EnrollmentEventRouter;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class EnrollmentEventController extends Controller
{
    public function __invoke(
        RouteEnrollmentEventRequest $request,
        EnrollmentEventRouter $router,
        EnrollmentEventFilter $filter,
    ): JsonResponse {
        $message = $request->validated();
        $message['correlation_id'] = $request->header('X-Correlation-ID') ?: (string) Str::uuid();

        if (! $filter->allows($message)) {
            return response()->json([
                'event_id' => $message['id'],
                'type' => $message['type'],
                'destination' => 'filtrados',
                'status' => 'filtrado',
                'reason' => 'La prioridad baja no supera el filtro de admisión.',
                'correlation_id' => $message['correlation_id'],
            ], 200)->header('X-Correlation-ID', $message['correlation_id']);
        }

        $destination = $router->destinationFor($message['type']);
        Log::info('message_router.decided', [
            'event_id' => $message['id'],
            'correlation_id' => $message['correlation_id'],
            'type' => $message['type'],
            'destination' => $destination,
        ]);

        if ($destination === 'no_enrutables') {
            Log::warning('message_router.unroutable', [
                'event_id' => $message['id'],
                'correlation_id' => $message['correlation_id'],
                'type' => $message['type'],
                'destination' => $destination,
            ]);

            return response()->json([
                'event_id' => $message['id'],
                'type' => $message['type'],
                'destination' => $destination,
                'status' => 'no_enrutable',
                'reason' => 'No existe una regla para este tipo de evento.',
                'correlation_id' => $message['correlation_id'],
            ], 202)->header('X-Correlation-ID', $message['correlation_id']);
        }

        $message['message_id'] = (string) Str::uuid();
        $message['occurred_at'] = now()->toIso8601String();
        $message['user_id'] = (string) $request->user()->getAuthIdentifier();
        $message['destination'] = $destination;

        Log::info('message_producer.queued', [
            'message_id' => $message['message_id'],
            'correlation_id' => $message['correlation_id'],
            'queue' => 'inscripciones',
            'status' => 'queued',
        ]);

        ProcessEnrollmentEvent::dispatch($message)->onQueue('inscripciones');

        return response()->json([
            'destination' => $destination,
            'status' => 'recibido',
            'message_id' => $message['message_id'],
            'event_id' => $message['id'],
            'correlation_id' => $message['correlation_id'],
            'queue' => 'inscripciones',
        ], 202)->header('X-Correlation-ID', $message['correlation_id']);
    }
}
